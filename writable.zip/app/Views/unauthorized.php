<h2>Unauthorized Access</h2>
<p>You do not have permission to access this page.</p>
<a href="/logout">Logout</a>
